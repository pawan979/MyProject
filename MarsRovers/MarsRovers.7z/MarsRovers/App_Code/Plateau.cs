﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Plateau
/// </summary>
public class Plateau
{
    #region Variables
        private int _Length;
        private int _Width;
        private Rovers _Rover;
    #endregion

    #region Properties

        public int Length
        {
            get { return _Length; }
            set { _Length = value; }
        }

        public int Width
        {
            get { return _Width; }
            set { _Width = value; }
        }

    #endregion

    #region Constructor

        public Plateau(int Length, int Width)
        {
            _Length = Length;
            _Width = Width;
        }
    
    #endregion

    #region Public Methods

        //Activate the rover on the plateau.
        public void ActiveRoverPlateau(Rovers Rover, Plateau MainPlateau)
        {
            string Output = null;

            try
            {
                _Rover = Rover;

                // Retriving the path of the output file.
                NameValueCollection Section = (NameValueCollection)System.Configuration.ConfigurationManager.GetSection("Directories");
                Output = Section["output"];

                // Initialisation of the rover.
                _Rover.InitialiseRover(MainPlateau);

                // Run the commands of the rover.
                _Rover.Start();


                // Write the output of the rover.
                System.IO.File.AppendAllText(Output, _Rover.Output);

            }
            finally
            {
                _Rover.Reset();
            }

        }


    #endregion

}