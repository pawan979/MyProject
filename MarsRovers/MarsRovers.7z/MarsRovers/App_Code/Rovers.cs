﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Rovers
/// </summary>
public class Rovers
{
    #region Variables

        #region Constant
            private const string PositionNotValid = "Position of the Rover is not valid.";
            private const string RoverCrossedBoundary = "The rover has crossed the plateau's boundary. ";
            private const string CommandNotValid = "Command is not valid. ";

        #endregion

        #region Private

        private char _Direction;

            private int _PositionX;
            private int _PositionY;
        
            private string _Position;
            private string _Command;
            public string Output;

            private Plateau _Plateau;

        #endregion 

        #region Protected
            protected static Rovers _Rover;

        #endregion

    #endregion

    #region Enumeration

            enum RoverCommands
            {
                Move = 'M',
                RotateRight = 'R',
                RotateLeft = 'L'
            }

            enum RoverDirections
            {
                North = 'N',
                South = 'S',
                East = 'E',
                West = 'W'
            }

    #endregion

    #region Constructors

        private Rovers(string Position, string Command)
        {
            _Position = Position;
            _Command = Command;
        }

    #endregion

    #region Public Methods

        // Reseting the rover.
        public void Reset()
        {
            _Rover = null;
            _PositionX = 0;
            _PositionY = 0;
            _Command = null;
        }
    
        // Creating a new instance of a rover
        public static Rovers getRover(string Position, string Command)
        {
            // Verify if the rover already exists.
            if (_Rover == null)
            {
                // Create new instance of rover.
                _Rover = new Rovers(Position, Command);

            }
            return _Rover;
        }

        // Initialising the rover.
        public void InitialiseRover(Plateau Plateau)
        {
            char Direction;
            int Position;
            string[] RoverPosition;

            _Plateau = Plateau;    
        
            RoverPosition = _Position.Split(null);
        
            // Verify is the rover's position is correct
            if(RoverPosition.Count() >=3)
            {
                // Getting th position of the rover.
               for (int i =0 ; i< RoverPosition.Count(); i++)
               {
                   switch (i)
                   {
                       case 0 :  // X-Coordinate of the rover.
                           if (Int32.TryParse(RoverPosition[i], out Position))
                          {
                              this._PositionX = Position;
                          }
                          break;

                       case 1:  // Y-Coordinate of the rover.
                          if (Int32.TryParse(RoverPosition[i], out Position))
                           {
                               this._PositionY = Position;
                           }
                           break;

                       case 2: // Direction the rover is pointing.
                           if (char.TryParse(RoverPosition[i], out Direction))
                          {
                              this._Direction = Direction;
                          }
                          break;

                       default :
                          throw new System.ArgumentException(PositionNotValid + Environment.NewLine);

                   }
               }

            
            }

        }

        // Run the commands of the rover.
        public void Start()
        {
            // Verify of the command is null.
            if (_Command != null)
            {
                // Looping each character in the commands.
                foreach (char Command in _Command)
                {
                    switch (Command)
                    {
                        case (char)RoverCommands.Move:  // Move the rover.

                            // Get the direction the rover is pointing.
                            switch (this._Direction)
                            {

                                case (char)RoverDirections.North:

                                    this._PositionY++;

                                    // Verify if the rover is on the plateau.
                                    if(RoverOnPlateau())
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        throw new System.ArgumentException(RoverCrossedBoundary + Environment.NewLine);
                                    }

                                case (char)RoverDirections.South:
                                    this._PositionY--;

                                    // Verify if the rover is on the plateau.
                                    if (RoverOnPlateau())
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        throw new System.ArgumentException(RoverCrossedBoundary + Environment.NewLine);
                                    }

                                case (char)RoverDirections.East:
                                    this._PositionX++;

                                    // Verify if the rover is on the plateau.
                                    if (RoverOnPlateau())
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        throw new System.ArgumentException(RoverCrossedBoundary + Environment.NewLine);
                                    }
                                case (char)RoverDirections.West:
                                    this._PositionX--;

                                    // Verify if the rover is on the plateau.
                                    if (RoverOnPlateau())
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        throw new System.ArgumentException(RoverCrossedBoundary + Environment.NewLine);
                                    }

                                default :

                                    // The command is not valid.
                                    throw new System.ArgumentException(CommandNotValid + Environment.NewLine);

                            }

                            break;

                        case (char)RoverCommands.RotateLeft:  // Make the rover spin 90 degrees left 
                            switch (this._Direction)
                            {
                                case (char)RoverDirections.North:

                                    // Set the new direction of the rover
                                    this._Direction = (char)RoverDirections.West; 
                                    break;

                                case (char)RoverDirections.South:

                                    // Set the new direction of the rover
                                    this._Direction = (char)RoverDirections.East; 
                                    break;

                                case (char)RoverDirections.East:

                                    // Set the new direction of the rover
                                    this._Direction = (char)RoverDirections.North; 
                                    break;

                                case (char)RoverDirections.West:

                                    // Set the new direction of the rover
                                    this._Direction = (char)RoverDirections.South; ;
                                    break;

                                default :

                                    // The command is not valid.
                                    throw new System.ArgumentException(CommandNotValid + Environment.NewLine);

                            }
                            break;

                        case (char)RoverCommands.RotateRight:  // Make the rover spin 90 degrees right 

                            switch (this._Direction)
                            {
                                case (char)RoverDirections.North:

                                    // Set the new direction of the rover
                                    this._Direction = (char)RoverDirections.East;
                                    break;

                                case (char)RoverDirections.South:

                                    // Set the new direction of the rover
                                    this._Direction = (char)RoverDirections.West; 
                                    break;

                                case (char)RoverDirections.East:

                                    // Set the new direction of the rover
                                    this._Direction = (char)RoverDirections.South; 
                                    break;

                                case (char)RoverDirections.West:

                                    // Set the new direction of the rover
                                    this._Direction = (char)RoverDirections.North; 
                                    break;

                                default:

                                    //The command is not valid.
                                    throw new System.ArgumentException(CommandNotValid + Environment.NewLine);
                            }
                            break;

                        default:

                            // The command is not valid.
                            throw new System.ArgumentException(CommandNotValid + Environment.NewLine);
                                            
                    }
                }

                // The position of the rover after the commands.
                Output = this._PositionX + " " + this._PositionY + " " + this._Direction + Environment.NewLine;
            }
        }

#endregion

    #region Private Methods

        //Verify if the rover is on the plateau.
        private bool RoverOnPlateau()
        {
            bool RoverOnPlateau = true;

            if ((_PositionX > _Plateau.Width) || (_PositionY > _Plateau.Length))
            {
                RoverOnPlateau = false;
            }

            return RoverOnPlateau;
        }

    #endregion

}