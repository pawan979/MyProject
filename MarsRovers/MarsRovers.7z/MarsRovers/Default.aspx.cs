﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    private Plateau MainPlateau;

    protected void Page_Load(object sender, EventArgs e)
    {
        string Input, Output = null;

        try 
	    {	
            Rovers ActiveRover;
            string[] PlateauSize;
            string[] RoverInfo;

            // Retrieving the Input and output file directory.
            NameValueCollection  Section = (NameValueCollection) System.Configuration.ConfigurationManager.GetSection("Directories");
            Input = Section["input"];
            Output = Section["output"];

            // Reading the content of the input file.
            RoverInfo = System.IO.File.ReadAllLines(Input);

            // Verify if the file is not empty.
            if (RoverInfo[0] == null )
            {
                throw new System.ArgumentException("The input file is empty." + Environment.NewLine);
            }

            // Verify if the plateau size is configured.
            if (RoverInfo[0].Trim().Split(null).Count() !=2)
            {
                 throw new System.ArgumentException("The plateau size is not configured." + Environment.NewLine);
            }

            // Retrieving the plateau info.
            PlateauSize = RoverInfo[0].Split(null);
            
            // Initialisating the plateau.
            MainPlateau = new Plateau(Convert.ToInt32(PlateauSize[0]), Convert.ToInt32(PlateauSize[1]));

            // Looping for each rover instance in the file.
            for (int i = 1; i < RoverInfo.Count(); i = i +2 )
            {
                // Initialising the rover.
                ActiveRover = Rovers.getRover(RoverInfo[i].Trim(), RoverInfo[i + 1].Trim());

                // Activate the rover.
                MainPlateau.ActiveRoverPlateau(ActiveRover, MainPlateau);
            }
		    
	    }
        catch (Exception ex)
        {
            // Write the exception in a text file.
            System.IO.File.AppendAllText(Output, ex.Message);
        }
      
	    finally
	    {
	    }

    }
}